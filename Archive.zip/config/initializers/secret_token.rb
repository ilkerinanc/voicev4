# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Voicev4::Application.config.secret_token = '64fa82513cba1a4a49ce332445c9e4237eb277cd8234183670a03e14e2821dd80c9f69ee6035cbd8934b2041b855f8a507e8393cf580c9a8fb5cd5fa4b300711'
